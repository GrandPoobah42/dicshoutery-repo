import React, { useEffect, useState, useRef } from 'react';
import { Sparkles, Clock, Mic, CheckCircle2, X } from 'lucide-react';
import { sound } from '../services/soundEffects';
import confetti from 'canvas-confetti';

interface AntonymBonusModalProps {
  targetWord: string;
  definition: string;
  antonyms: string[];
  primaryAntonym: string;
  onSuccess: (antonym: string) => void;
  onExpire: () => void;
  lastTranscript: string;
}

export const AntonymBonusModal: React.FC<AntonymBonusModalProps> = ({
  targetWord,
  definition,
  antonyms,
  primaryAntonym,
  onSuccess,
  onExpire,
  lastTranscript,
}) => {
  const TOTAL_TIME = 5.0; // 5 seconds
  const [timeLeft, setTimeLeft] = useState<number>(TOTAL_TIME);
  const [solved, setSolved] = useState<boolean>(false);
  const [matchedAntonym, setMatchedAntonym] = useState<string>('');
  const handledRef = useRef<boolean>(false);

  // Countdown timer
  useEffect(() => {
    const interval = 100; // 100ms
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        const next = Math.max(0, parseFloat((prev - 0.1).toFixed(1)));
        if (next <= 0 && !handledRef.current) {
          handledRef.current = true;
          clearInterval(timer);
          setTimeout(() => onExpire(), 1200);
        }
        return next;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [onExpire]);

  // Voice transcript matching
  useEffect(() => {
    if (!lastTranscript || solved || handledRef.current) return;
    const cleanSpeech = lastTranscript.toUpperCase();

    // Check if any accepted antonym is spoken
    const found = antonyms.find(ant => {
      const regex = new RegExp(`\\b${ant}\\b`, 'i');
      return regex.test(cleanSpeech) || cleanSpeech.includes(ant);
    });

    if (found) {
      handledRef.current = true;
      setSolved(true);
      setMatchedAntonym(found);
      sound.playAntonymBonus();

      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });

      setTimeout(() => {
        onSuccess(found);
      }, 1400);
    }
  }, [lastTranscript, solved, antonyms, onSuccess]);

  const handleManualSelect = (candidate: string) => {
    if (solved || handledRef.current) return;
    handledRef.current = true;
    setSolved(true);
    setMatchedAntonym(candidate);
    sound.playAntonymBonus();

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 },
    });

    setTimeout(() => {
      onSuccess(candidate);
    }, 1200);
  };

  const progressPercent = Math.max(0, (timeLeft / TOTAL_TIME) * 100);

  // Generate 3 choices (1 correct antonym + 2 distracting non-antonyms) for rapid tap
  const distractors = ['BRIGHT', 'ANCIENT', 'SILENT', 'HEAVY', 'GENTLE', 'SWIFT'].filter(
    w => !antonyms.includes(w) && w !== targetWord
  );
  const choices = React.useMemo(() => {
    const opts = [primaryAntonym, distractors[0] || 'COMPLEX', distractors[1] || 'RANDOM'];
    return opts.sort(() => Math.random() - 0.5);
  }, [primaryAntonym]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 border-2 border-amber-500/80 rounded-2xl shadow-2xl p-6 relative overflow-hidden">
        {/* Progress bar along top edge */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-slate-100 dark:bg-slate-800">
          <div
            className={`h-full transition-all duration-100 ${
              progressPercent > 35 ? 'bg-amber-500' : 'bg-rose-500'
            }`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Header Badge */}
        <div className="flex items-center justify-between mb-4 mt-1">
          <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-bold text-sm tracking-wide uppercase">
            <Sparkles className="w-5 h-5 animate-spin" />
            <span>Oxford Antonym Rush Bonus!</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-lg text-amber-700 dark:text-amber-300 font-mono-numbers text-sm font-bold">
            <Clock className="w-4 h-4 text-amber-500" />
            <span>{timeLeft.toFixed(1)}s</span>
          </div>
        </div>

        {/* Found Word Display */}
        <div className="text-center py-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 mb-4">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            You Found
          </span>
          <h3 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-wider my-1">
            {targetWord}
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 italic px-4 line-clamp-2">
            "{definition}"
          </p>
        </div>

        {/* Solved state vs Guessing state */}
        {solved ? (
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 text-center animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-lg mb-1">
              <CheckCircle2 className="w-6 h-6" />
              <span>Antonym Matched!</span>
            </div>
            <p className="text-sm font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              "{matchedAntonym}"
            </p>
            <div className="flex items-center justify-center gap-3 mt-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300 font-mono-numbers">
              <span>+300 Points</span>
              <span>·</span>
              <span>+5.0s Added to Clock!</span>
            </div>
          </div>
        ) : timeLeft <= 0 ? (
          <div className="bg-slate-100 dark:bg-slate-800 rounded-xl p-4 text-center">
            <span className="text-xs text-slate-500 dark:text-slate-400 uppercase font-semibold">
              Time Expired!
            </span>
            <p className="text-sm text-slate-700 dark:text-slate-300 mt-1">
              Accepted antonym was:{' '}
              <strong className="text-amber-600 dark:text-amber-400 uppercase">
                {primaryAntonym}
              </strong>
            </p>
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-center gap-2 text-slate-700 dark:text-slate-300 text-sm font-semibold mb-3">
              <Mic className="w-4 h-4 text-emerald-500 animate-pulse" />
              <span>Shout an antonym or tap below:</span>
            </div>

            {/* Quick-tap options */}
            <div className="grid grid-cols-3 gap-2">
              {choices.map(choice => (
                <button
                  key={choice}
                  onClick={() => handleManualSelect(choice)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold uppercase transition-all tracking-wider ${
                    antonyms.includes(choice)
                      ? 'bg-slate-100 dark:bg-slate-800 hover:bg-emerald-500 hover:text-white text-slate-900 dark:text-white border border-slate-300 dark:border-slate-700 hover:border-emerald-500'
                      : 'bg-slate-100 dark:bg-slate-800 hover:bg-rose-500 hover:text-white text-slate-900 dark:text-white border border-slate-300 dark:border-slate-700'
                  }`}
                >
                  {choice}
                </button>
              ))}
            </div>

            <div className="mt-3 text-center">
              <span className="text-[11px] text-slate-400">
                Bonus: +300 points &amp; +5 seconds on clock!
              </span>
            </div>
          </div>
        )}

        {/* Skip button */}
        <button
          onClick={onExpire}
          className="mt-4 w-full py-1.5 text-center text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
        >
          Skip Antonym Bonus
        </button>
      </div>
    </div>
  );
};
