/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { HUD } from './components/HUD';
import { WordSearchGrid, FoundWordDisplay } from './components/WordSearchGrid';
import { WordListLedger, DiscoveredWordItem } from './components/WordListLedger';
import { AudioVisualizer } from './components/AudioVisualizer';
import { AntonymBonusModal } from './components/AntonymBonusModal';
import { GameOverModal } from './components/GameOverModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { VoiceTuningModal } from './components/VoiceTuningModal';
import { PassDeviceModal, Player } from './components/PassDeviceModal';
import { MultiplayerPodiumModal } from './components/MultiplayerPodiumModal';
import { OXFORD_LEXICON, findLexiconWord } from './data/dictionary';
import {
  generateWordSearch,
  findWordInGrid,
  GeneratedBoard,
  Coordinate,
  VIBRANT_WORD_COLORS,
} from './utils/wordSearchGenerator';
import { speechController } from './services/speechRecognition';
import { sound } from './services/soundEffects';
import {
  Play,
  HelpCircle,
  Trophy,
  Sparkles,
  Users,
  User,
  Plus,
  Trash2,
  Mic,
  Flame,
  Volume2,
  CheckCircle2,
  Wand2,
} from 'lucide-react';
import confetti from 'canvas-confetti';

type GameState = 'TITLE_MENU' | 'PLAYING' | 'PASS_DEVICE' | 'PODIUM' | 'GAME_OVER';
type GameMode = 'SOLO' | 'MULTIPLAYER';

const PLAYER_COLORS = ['#10B981', '#F59E0B', '#EC4899', '#6366F1'];

interface StageConfig {
  gridSize: number;
  seedCount: number;
  timeLimit: number;
}

const getStageConfig = (level: number): StageConfig => {
  switch (level) {
    case 1:
      return { gridSize: 9, seedCount: 18, timeLimit: 60 };
    case 2:
      return { gridSize: 10, seedCount: 22, timeLimit: 55 };
    case 3:
      return { gridSize: 11, seedCount: 25, timeLimit: 50 };
    default:
      return {
        gridSize: Math.min(12, 10 + Math.floor((level - 2) / 2)),
        seedCount: Math.min(28, 22 + (level - 3) * 2),
        timeLimit: Math.max(45, 55 - (level - 3) * 5),
      };
  }
};

export default function App() {
  const [gameState, setGameState] = useState<GameState>('TITLE_MENU');
  const [gameMode, setGameMode] = useState<GameMode>('SOLO');
  const [level, setLevel] = useState<number>(1);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved =
        localStorage.getItem('dicshoutery_high_score') ||
        localStorage.getItem('lexishout_high_score');
      return saved ? parseInt(saved, 10) : 0;
    }
    return 0;
  });
  const [streak, setStreak] = useState<number>(1);
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [totalRoundTime, setTotalRoundTime] = useState<number>(60);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [lastTranscript, setLastTranscript] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Regional Accent Voice Tuning
  const [showVoiceTuning, setShowVoiceTuning] = useState<boolean>(false);
  const [pendingStartMode, setPendingStartMode] = useState<GameMode | null>(null);
  const [isVoiceCalibrated, setIsVoiceCalibrated] = useState<boolean>(() =>
    speechController.isAccentCalibrated()
  );

  // Multiplayer State
  const [players, setPlayers] = useState<Player[]>([
    { id: 'p1', name: 'Player 1', color: '#10B981', score: 0, wordsCount: 0, antonymsCount: 0 },
    { id: 'p2', name: 'Player 2', color: '#F59E0B', score: 0, wordsCount: 0, antonymsCount: 0 },
  ]);
  const [currentPlayerIdx, setCurrentPlayerIdx] = useState<number>(0);
  const [currentRound, setCurrentRound] = useState<number>(1);
  const [totalRounds, setTotalRounds] = useState<number>(2);
  const [finishedTurnPlayer, setFinishedTurnPlayer] = useState<Player | null>(null);

  // Board and Discovered words
  const [board, setBoard] = useState<GeneratedBoard | null>(null);
  const [discoveredWords, setDiscoveredWords] = useState<DiscoveredWordItem[]>([]);

  // Active Antonym Bonus State
  const [activeBonusItem, setActiveBonusItem] = useState<DiscoveredWordItem | null>(null);

  // Modals
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2000);
  };

  const toggleMute = () => {
    const next = sound.toggleMuted();
    setIsMuted(next);
  };

  // Setup a stage
  const setupStage = useCallback((stageLevel: number) => {
    const config = getStageConfig(stageLevel);
    setTimeLeft(config.timeLimit);
    setTotalRoundTime(config.timeLimit);
    setDiscoveredWords([]);
    setActiveBonusItem(null);
    setStreak(1);

    const generated = generateWordSearch(OXFORD_LEXICON, config.gridSize, config.seedCount);
    setBoard(generated);
  }, []);

  // Launch Solo Game Direct
  const handleStartSoloDirect = async () => {
    setGameMode('SOLO');
    setLevel(1);
    setScore(0);
    setStreak(1);
    setupStage(1);
    setGameState('PLAYING');

    try {
      await speechController.startListening();
    } catch {}
  };

  // Launch Multiplayer Game Direct
  const handleStartMultiplayerDirect = async () => {
    setGameMode('MULTIPLAYER');
    setLevel(1);
    setCurrentPlayerIdx(0);
    setCurrentRound(1);

    const freshPlayers = players.map(p => ({
      ...p,
      score: 0,
      wordsCount: 0,
      antonymsCount: 0,
    }));
    setPlayers(freshPlayers);

    setupStage(1);
    setScore(0);
    setGameState('PLAYING');

    try {
      await speechController.startListening();
    } catch {}
  };

  // Check calibration before playing
  const handleRequestStartSolo = () => {
    if (!speechController.isAccentCalibrated()) {
      setPendingStartMode('SOLO');
      setShowVoiceTuning(true);
    } else {
      handleStartSoloDirect();
    }
  };

  const handleRequestStartMultiplayer = () => {
    if (!speechController.isAccentCalibrated()) {
      setPendingStartMode('MULTIPLAYER');
      setShowVoiceTuning(true);
    } else {
      handleStartMultiplayerDirect();
    }
  };

  const handleTuningCompleted = () => {
    setShowVoiceTuning(false);
    setIsVoiceCalibrated(true);
    showToast('Voice successfully tuned to your regional accent!');

    if (pendingStartMode === 'MULTIPLAYER') {
      handleStartMultiplayerDirect();
    } else {
      handleStartSoloDirect();
    }
    setPendingStartMode(null);
  };

  const handleTuningSkipped = () => {
    setShowVoiceTuning(false);
    if (pendingStartMode === 'MULTIPLAYER') {
      handleStartMultiplayerDirect();
    } else if (pendingStartMode === 'SOLO') {
      handleStartSoloDirect();
    }
    setPendingStartMode(null);
  };

  // Add / Remove players in multiplayer setup
  const handleAddPlayer = () => {
    if (players.length >= 4) return;
    const newIdx = players.length;
    const newColor = PLAYER_COLORS[newIdx % PLAYER_COLORS.length];
    setPlayers(prev => [
      ...prev,
      {
        id: `p${newIdx + 1}`,
        name: `Player ${newIdx + 1}`,
        color: newColor,
        score: 0,
        wordsCount: 0,
        antonymsCount: 0,
      },
    ]);
  };

  const handleRemovePlayer = (id: string) => {
    if (players.length <= 2) return;
    setPlayers(prev => prev.filter(p => p.id !== id));
  };

  const handleUpdatePlayerName = (id: string, name: string) => {
    setPlayers(prev => prev.map(p => (p.id === id ? { ...p, name } : p)));
  };

  // Restart Round
  const handleRestartRound = () => {
    setupStage(level);
    setGameState('PLAYING');
  };

  const handleNextStage = () => {
    const nextLvl = level + 1;
    setLevel(nextLvl);
    setupStage(nextLvl);
    setGameState('PLAYING');
  };

  // Word Discovery Handler - Strictly rejects non-words
  const processDiscoveredWord = useCallback(
    (candidate: string, explicitPath?: Coordinate[], byVoice: boolean = false) => {
      if (!board || gameState !== 'PLAYING') return;

      const upper = candidate.trim().toUpperCase();
      if (upper.length < 2) return;

      // 1. STRICT LEXICON CHECK: Must be a verified English dictionary entry
      const lexiconEntry = findLexiconWord(upper);
      if (!lexiconEntry) {
        if (!byVoice) {
          sound.playPip(160, 0.12);
          showToast(`"${upper}" is not a recognized English word`);
        }
        return;
      }

      // 2. Already spotted check
      const alreadyFound = discoveredWords.some(w => w.word === upper);
      if (alreadyFound) {
        showToast(`"${upper}" was already spotted!`);
        return;
      }

      // 3. Grid presence check
      let path = explicitPath;
      if (!path) {
        path = findWordInGrid(board.grid, upper) || undefined;
      }

      if (!path) {
        if (!byVoice) {
          sound.playPip(180, 0.12);
          showToast(`"${upper}" is not on the grid`);
        }
        return;
      }

      const color = VIBRANT_WORD_COLORS[discoveredWords.length % VIBRANT_WORD_COLORS.length];

      // Scoring: 1 point per letter!
      const letterPoints = upper.length;
      const voiceMultiplier = byVoice ? 1.5 : 1.0;
      const streakMultiplier = Math.min(4, streak);
      const earned = Math.round(letterPoints * voiceMultiplier * streakMultiplier);

      const newItem: DiscoveredWordItem = {
        id: `found-${upper}-${Date.now()}`,
        word: upper,
        tier: lexiconEntry.tier,
        path,
        found: true,
        foundByVoice: byVoice,
        color,
        definition: lexiconEntry.definition,
        antonyms: lexiconEntry.antonyms,
        primaryAntonym: lexiconEntry.primaryAntonym,
        earnedPoints: earned,
        antonymSolved: false,
      };

      sound.playWordFound(byVoice);
      confetti({
        particleCount: 55,
        spread: 70,
        origin: { y: 0.7 },
      });

      setDiscoveredWords(prev => [newItem, ...prev]);

      setScore(prev => {
        const nextScore = prev + earned;
        if (gameMode === 'SOLO' && nextScore > highScore) {
          setHighScore(nextScore);
          localStorage.setItem('dicshoutery_high_score', nextScore.toString());
        }
        return nextScore;
      });

      if (gameMode === 'MULTIPLAYER') {
        setPlayers(prev =>
          prev.map((p, idx) =>
            idx === currentPlayerIdx
              ? { ...p, score: p.score + earned, wordsCount: p.wordsCount + 1 }
              : p
          )
        );
      }

      setStreak(prev => Math.min(5, prev + 1));

      if (newItem.antonyms.length > 0) {
        setActiveBonusItem(newItem);
      } else {
        showToast(`Spotted "${upper}"! (+${earned} pts for ${letterPoints} letters)`);
      }
    },
    [board, gameState, discoveredWords, streak, highScore, gameMode, currentPlayerIdx]
  );

  // Drag selection from grid - strictly validates against Oxford Lexicon
  const handleSelectLetters = (word: string, path: Coordinate[]) => {
    const forward = word.toUpperCase();
    const backward = [...forward].reverse().join('');

    const lexForward = findLexiconWord(forward);
    const lexBackward = findLexiconWord(backward);

    if (lexForward) {
      processDiscoveredWord(forward, path, false);
    } else if (lexBackward) {
      processDiscoveredWord(backward, [...path].reverse(), false);
    } else {
      sound.playPip(160, 0.12);
      showToast(`"${forward}" is not a recognized English word`);
    }
  };

  const handleShoutWord = (word: string) => {
    processDiscoveredWord(word, undefined, false);
  };

  // Continuous speech listener
  useEffect(() => {
    const unsub = speechController.onVoiceDetected((cleanWord, fullTranscript) => {
      setLastTranscript(fullTranscript);

      if (gameState === 'PLAYING' && board && !activeBonusItem) {
        processDiscoveredWord(cleanWord, undefined, true);
      }
    });

    return () => unsub();
  }, [gameState, board, activeBonusItem, processDiscoveredWord]);

  // Antonym Bonus Resolution
  const handleAntonymSuccess = (solvedAntonym: string) => {
    if (!activeBonusItem) return;

    const bonusPoints = 300 * Math.min(4, streak);
    setScore(prev => {
      const nextScore = prev + bonusPoints;
      if (gameMode === 'SOLO' && nextScore > highScore) {
        setHighScore(nextScore);
        localStorage.setItem('dicshoutery_high_score', nextScore.toString());
      }
      return nextScore;
    });

    if (gameMode === 'MULTIPLAYER') {
      setPlayers(prev =>
        prev.map((p, idx) =>
          idx === currentPlayerIdx
            ? { ...p, score: p.score + bonusPoints, antonymsCount: p.antonymsCount + 1 }
            : p
        )
      );
    }

    setTimeLeft(prev => Math.min(totalRoundTime + 15, prev + 5));

    setDiscoveredWords(prev =>
      prev.map(w =>
        w.id === activeBonusItem.id
          ? { ...w, antonymSolved: true, solvedAntonymText: solvedAntonym }
          : w
      )
    );

    showToast(`Antonym Solved: "${solvedAntonym}"! (+${bonusPoints} pts & +5s)`);
    setActiveBonusItem(null);
  };

  const handleAntonymExpire = () => {
    setActiveBonusItem(null);
  };

  // Countdown timer with Progressive Volume Scaling & End Pips
  useEffect(() => {
    if (gameState !== 'PLAYING') return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        const nextTime = prev - 1;

        sound.playDynamicTimerTick(nextTime, totalRoundTime);

        if (nextTime <= 0) {
          clearInterval(timer);

          if (gameMode === 'MULTIPLAYER') {
            handleMultiplayerTurnEnd();
          } else {
            sound.playGameOver();
            setGameState('GAME_OVER');
          }
          return 0;
        }

        return nextTime;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState, gameMode, totalRoundTime, currentPlayerIdx, currentRound, totalRounds, players]);

  // Multiplayer Turn End Handler
  const handleMultiplayerTurnEnd = () => {
    const finished = players[currentPlayerIdx];
    setFinishedTurnPlayer(finished);

    const nextIdx = currentPlayerIdx + 1;

    if (nextIdx < players.length) {
      setGameState('PASS_DEVICE');
    } else {
      if (currentRound < totalRounds) {
        setGameState('PASS_DEVICE');
      } else {
        setGameState('PODIUM');
      }
    }
  };

  const handleStartNextTurn = () => {
    const nextIdx = currentPlayerIdx + 1;
    if (nextIdx < players.length) {
      setCurrentPlayerIdx(nextIdx);
    } else {
      setCurrentPlayerIdx(0);
      setCurrentRound(prev => prev + 1);
    }

    setupStage(level);
    setScore(0);
    setGameState('PLAYING');
  };

  const activePlayer = gameMode === 'MULTIPLAYER' ? players[currentPlayerIdx] : null;
  const nextPlayer =
    gameMode === 'MULTIPLAYER'
      ? players[(currentPlayerIdx + 1) % players.length]
      : players[0];

  const foundWordsDisplay: FoundWordDisplay[] = discoveredWords.map(w => ({
    id: w.id,
    word: w.word,
    path: w.path,
    color: w.color,
  }));

  const hiddenRemainingWords = React.useMemo(() => {
    if (!board) return [];
    const foundSet = new Set(discoveredWords.map(w => w.word));
    return board.allHiddenWords.map(w => w.word).filter(w => !foundSet.has(w));
  }, [board, discoveredWords]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-100/40 via-rose-50/30 to-emerald-100/40 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 text-white px-7 py-3 rounded-full font-black text-xs sm:text-sm tracking-wide shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-top-4 duration-150">
          {toastMessage}
        </div>
      )}

      {/* TITLE MENU & MULTIPLAYER SETUP */}
      {gameState === 'TITLE_MENU' && (
        <main className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 max-w-4xl mx-auto w-full my-auto">
          <div className="w-full bg-white dark:bg-slate-900 border-2 border-amber-400 dark:border-amber-500/80 rounded-3xl p-6 sm:p-10 shadow-2xl shadow-amber-500/10 text-center relative overflow-hidden">
            {/* Playful energetic glows */}
            <div className="absolute -top-24 -left-24 w-80 h-80 bg-gradient-to-r from-amber-400/25 to-pink-500/20 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-gradient-to-r from-emerald-400/25 to-cyan-500/20 rounded-full blur-3xl pointer-events-none" />

            {/* Top Badges (High Score + Regional Accent Voice Calibrated) */}
            <div className="flex flex-wrap items-center justify-center gap-2 mb-4">
              {highScore > 0 && (
                <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-amber-400/20 to-amber-500/20 border-2 border-amber-400 text-amber-800 dark:text-amber-300 font-black text-xs font-mono-numbers shadow-sm">
                  <Trophy className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span>Solo Record: {highScore.toLocaleString()} pts</span>
                </div>
              )}

              <button
                type="button"
                onClick={() => setShowVoiceTuning(true)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border-2 text-xs font-black transition-all cursor-pointer shadow-sm ${
                  isVoiceCalibrated
                    ? 'bg-emerald-500/15 border-emerald-500 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/25'
                    : 'bg-amber-400/20 border-amber-400 text-amber-800 dark:text-amber-300 hover:bg-amber-400/30'
                }`}
                title="Calibrate your regional accent with 5 quick words"
              >
                {isVoiceCalibrated ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Regional Accent Tuned ✓</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                    <span>Tune Regional Voice (5 Words)</span>
                  </>
                )}
              </button>
            </div>

            {/* Title & Tagline */}
            <h1 className="text-5xl sm:text-7xl font-black tracking-tight text-slate-900 dark:text-white mb-2">
              Dic<span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500">shout</span>
              <span className="text-amber-500">ery!</span>
            </h1>
            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-xl mx-auto leading-relaxed mb-8">
              Spot hidden words on the matrix,{' '}
              <strong className="text-slate-900 dark:text-white font-bold">
                shout them aloud into your mic
              </strong>
              , and crack the antonym for huge bonus points!
            </p>

            {/* Mode Selector Tabs */}
            <div className="flex items-center justify-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl max-w-md mx-auto mb-8 border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setGameMode('SOLO')}
                className={`flex-1 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  gameMode === 'SOLO'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-md'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <User className="w-4 h-4" />
                <span>Solo Hunt</span>
              </button>

              <button
                type="button"
                onClick={() => setGameMode('MULTIPLAYER')}
                className={`flex-1 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  gameMode === 'MULTIPLAYER'
                    ? 'bg-gradient-to-r from-amber-500 to-pink-500 text-white shadow-md'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Pass &amp; Play Party</span>
              </button>
            </div>

            {/* Multiplayer Setup Card */}
            {gameMode === 'MULTIPLAYER' && (
              <div className="max-w-lg mx-auto mb-8 p-5 rounded-2xl bg-gradient-to-b from-amber-50/40 to-white dark:from-slate-800/80 dark:to-slate-800/40 border-2 border-amber-300 dark:border-amber-500/50 text-left animate-in fade-in zoom-in-95 duration-200 shadow-lg">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Players (2 to 4)
                  </h3>
                  {players.length < 4 && (
                    <button
                      type="button"
                      onClick={handleAddPlayer}
                      className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Player</span>
                    </button>
                  )}
                </div>

                <div className="space-y-2.5 mb-4">
                  {players.map((p, idx) => (
                    <div key={p.id} className="flex items-center gap-2.5">
                      <span
                        className="w-5 h-5 rounded-full shrink-0 shadow-sm ring-2 ring-white"
                        style={{ backgroundColor: p.color }}
                      />
                      <input
                        type="text"
                        value={p.name}
                        onChange={e => handleUpdatePlayerName(p.id, e.target.value)}
                        placeholder={`Player ${idx + 1}`}
                        className="flex-1 bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-black text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                      {players.length > 2 && (
                        <button
                          type="button"
                          onClick={() => handleRemovePlayer(p.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-700 text-xs">
                  <span className="font-bold text-slate-700 dark:text-slate-300">
                    Rounds per player:
                  </span>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3].map(r => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setTotalRounds(r)}
                        className={`w-8 h-8 rounded-xl font-black font-mono-numbers transition-all cursor-pointer ${
                          totalRounds === r
                            ? 'bg-amber-400 text-slate-950 shadow-md ring-2 ring-amber-300'
                            : 'bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Launch Action */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={gameMode === 'SOLO' ? handleRequestStartSolo : handleRequestStartMultiplayer}
                className="w-full sm:w-auto px-10 py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-base tracking-wide transition-all shadow-xl shadow-emerald-500/30 hover:scale-[1.02] flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-5 h-5 fill-slate-950" />
                <span>
                  {gameMode === 'SOLO' ? 'Start Solo Game' : `Start Party (${players.length} Players)`}
                </span>
              </button>
              <button
                onClick={() => setShowHowToPlay(true)}
                className="w-full sm:w-auto px-6 py-4 rounded-2xl bg-white hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-base border-2 border-slate-200 dark:border-slate-700 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <HelpCircle className="w-5 h-5 text-amber-500" />
                <span>How to Play</span>
              </button>
            </div>
          </div>
        </main>
      )}

      {/* ACTIVE PLAYING SCREEN */}
      {gameState === 'PLAYING' && board && (
        <div className="flex-1 flex flex-col">
          <HUD
            level={level}
            score={score}
            highScore={highScore}
            streak={streak}
            timeLeft={timeLeft}
            totalRoundTime={totalRoundTime}
            onOpenHowToPlay={() => setShowHowToPlay(true)}
            onRestart={handleRestartRound}
            isMuted={isMuted}
            onToggleMute={toggleMute}
            activePlayer={activePlayer}
            roundNumber={currentRound}
            totalRounds={totalRounds}
            isMultiplayer={gameMode === 'MULTIPLAYER'}
          />

          <main className="flex-1 max-w-6xl mx-auto w-full p-4 sm:p-6 flex flex-col gap-4">
            <AudioVisualizer
              onShoutWord={handleShoutWord}
              lastTranscript={lastTranscript}
            />

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Matrix */}
              <div className="lg:col-span-8 flex flex-col items-center justify-center bg-white dark:bg-slate-900 border-2 border-amber-300 dark:border-amber-500/60 rounded-3xl p-4 sm:p-6 shadow-xl">
                <WordSearchGrid
                  grid={board.grid}
                  foundWords={foundWordsDisplay}
                  onSelectLetters={handleSelectLetters}
                  size={board.size}
                  maxViableWordLength={board.maxViableWordLength}
                />
              </div>

              {/* Discovered Ledger */}
              <div className="lg:col-span-4 h-full">
                <WordListLedger
                  discoveredWords={discoveredWords}
                  onTriggerAntonymBonus={item => {
                    if (item.antonyms.length > 0 && !item.antonymSolved) {
                      setActiveBonusItem(item);
                    }
                  }}
                />
              </div>
            </div>
          </main>
        </div>
      )}

      {/* PASS DEVICE TRANSITION MODAL (MULTIPLAYER) */}
      {gameState === 'PASS_DEVICE' && finishedTurnPlayer && (
        <PassDeviceModal
          finishedPlayer={finishedTurnPlayer}
          nextPlayer={nextPlayer}
          roundNumber={currentRound}
          totalRounds={totalRounds}
          onStartNextTurn={handleStartNextTurn}
        />
      )}

      {/* MULTIPLAYER PODIUM & WINNER MODAL */}
      {gameState === 'PODIUM' && (
        <MultiplayerPodiumModal
          players={players}
          onRematch={handleStartMultiplayerDirect}
          onMainMenu={() => setGameState('TITLE_MENU')}
        />
      )}

      {/* SOLO GAME OVER MODAL */}
      {gameState === 'GAME_OVER' && (
        <GameOverModal
          score={score}
          highScore={highScore}
          level={level}
          discoveredWords={discoveredWords}
          hiddenWordsRemaining={hiddenRemainingWords}
          onNextStage={handleNextStage}
          onRestart={handleRestartRound}
        />
      )}

      {/* ANTONYM BONUS MODAL */}
      {activeBonusItem && (
        <AntonymBonusModal
          targetWord={activeBonusItem.word}
          definition={activeBonusItem.definition}
          antonyms={activeBonusItem.antonyms}
          primaryAntonym={activeBonusItem.primaryAntonym}
          onSuccess={handleAntonymSuccess}
          onExpire={handleAntonymExpire}
          lastTranscript={lastTranscript}
        />
      )}

      {/* VOICE ACCENT TUNING MODAL */}
      {showVoiceTuning && (
        <VoiceTuningModal
          onComplete={handleTuningCompleted}
          onClose={handleTuningSkipped}
        />
      )}

      {/* HOW TO PLAY MODAL */}
      {showHowToPlay && <HowToPlayModal onClose={() => setShowHowToPlay(false)} />}
    </div>
  );
}
