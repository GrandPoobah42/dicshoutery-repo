# LexiShout: Voice-Activated Rapid Word Search

A fast-paced, progressive word search game where players spot hidden English words and shout them aloud using continuous microphone recognition for instant clearing and bonus multipliers, followed by a rapid-fire antonym challenge.

### User Review & Critical Decisions

> [!IMPORTANT]
> The core gameplay loop and speech mechanics were confirmed in Phase 1:
> - **Continuous Microphone Recognition**: Hands-free live listening mode automatically detects spoken words as soon as you shout them, with a visual audio waveform indicator.
> - **Dual Input Strategy**: Players can shout out words or drag/tap across grid tiles, accommodating any environment (silent play or active voice party mode).
> - **Antonym Bonus Window**: When a word is shouted out or found, a dynamic 5-second bonus timer activates—shouting or selecting a valid antonym awards extra score and adds precious seconds back to the countdown clock.

- **Confirmed Decision 1**: Hands-free continuous speech recognition with `webkitSpeechRecognition` / `SpeechRecognition` fallback and instant phonetic match.
- **Confirmed Decision 2**: Dual input support (voice shout-out and tactile drag/click tile selector).
- **Confirmed Decision 3**: 5-second rapid Antonym Bonus opportunity window triggering immediately upon word discovery.
- **Dictionary Source & Progression**: Curated Oxford-standard English dictionary with categorized difficulty tiers (Tier 1: Familiar 4-5 letters, Tier 2: Intermediate 5-7 letters, Tier 3: Advanced/Academic 6-9 letters, Tier 4: Master 8-12 letters), verified definitions, and paired antonym lookups.

---

### 1. Overview & Core Concept

- **What It Does**:
  LexiShout puts players into an adrenaline-fueled word search challenge. A dynamic letter grid hides English words placed horizontally, vertically, and diagonally. Instead of only squinting and dragging a finger, players can simply shout out words the moment they spot them. The app immediately validates the word against the grid, highlights and slashes the found entry with synthesized audio chimes, awards quick-reaction score multipliers, and triggers a 5-second Antonym Challenge window for bonus points.
- **Progression Loop**:
  Each completed stage introduces larger grids (from 8x8 to 12x12), less time on the clock (e.g. 90s -> 75s -> 60s), tougher vocabulary with rich Oxford definitions, and higher scoring streaks.
- **Target Audience**:
  Word puzzle enthusiasts, vocabulary builders, competitive party players, and language learners who enjoy fast reflexes and vocal gaming.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Title & Difficulty Hub**:
   - High-contrast, clean game banner, player high-score badge, microphone permission test widget with live audio feedback meter, and game mode selector (Standard Blitz, Endless Practice, Antonym Mania).
2. **Active Puzzle Grid View**:
   - **Top HUD**: Round countdown timer with pulsing urgency color, score counter with streak multiplier, words found count (e.g. `4 / 6`), and active mic listener state.
   - **Central Playing Field**: Generous, high-contrast grid cells ($\ge 44\text{px}$) with crisp typography, smooth selection trail, and vibrant highlight colors for discovered words.
   - **Target Words Ledger**: Clean list of hidden words with letter counts and Oxford definitions revealed upon discovery.
   - **Live Voice HUD**: Floating reactive waveform visualizer showing live voice activity and recent audio transcripts.
3. **Antonym Bonus Popup Modal / Banner**:
   - Triggers right after a word is shouted: a clean 5-second shrinking radial timer showing the target word (e.g. `"EXPAND"`) and prompting: *"Shout an antonym! (e.g. CONTRACT, SHRINK)"*. Correct voice callout adds +250 points and +5 seconds!
4. **Round Summary & Victory**:
   - Stage clear breakdown: Voice accuracy, words found, antonyms mastered, total score, and next level launch button.

#### Visual Identity & Theme
- **Aesthetic Direction**: Neo-arcade typography paired with an elegant, modern editorial word puzzle layout. Warm charcoal canvas with emerald and amber accents for discovery and time pressure.
- **Color Palette (60-30-10 Rule)**:
  - Canvas (60%): Deep slate / obsidian background (`#0B0F17` / dark mode slate `#111827`) or crisp parchment light mode (`#F8FAFC`).
  - Structural Surfaces (30%): Elevated card panels (`#1E293B` dark, `#FFFFFF` light), hairline slate dividers, and high-legibility tile surfaces.
  - Accent (10%): Electric emerald (`#10B981`) for word discovery, radiant amber (`#F59E0B`) for countdown urgency & antonym bonuses, and royal indigo (`#6366F1`) for selected letter trails.
- **Typography**:
  - Display: `Plus Jakarta Sans` / `Outfit` for bold legible tile letters and clean game titles.
  - Body & Definitions: Clean sans-serif with comfortable line height.
  - Timers & Scores: Tabular numerals (`tabular-nums font-mono`) for rock-solid stability without jitter.
- **Tactile Feedback & Audio**:
  - Web Audio API synthesized harmonic chimes for discovery, celebratory chords for stage clear, ticking urgency for the last 10 seconds, and quick pop clicks on tile interaction.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Real-time Speech Recognition Engine**
  - *Chosen Approach*: Web Speech API (`webkitSpeechRecognition` / `SpeechRecognition`) running in continuous mode with phonetic normalization (stripping accents, trailing spaces, case-insensitive mapping), backed by an instant-input button/keyboard fallback if the microphone is muted or unavailable.
  - *Why*: Delivers zero-latency speech detection natively in the browser without requiring heavy external cloud audio streaming costs or latency.
- **Decision 2: Offline-First Oxford Dictionary & Antonym Bank**
  - *Chosen Approach*: Comprehensive bundled English dictionary dataset categorized into 4 progressive difficulty tiers with curated antonym pairings and Oxford-style definitions.
  - *Why*: Instantaneous validation of shouted words within <50ms with no server roundtrip delays, ensuring the fast-paced game loop feels buttery smooth and never stutters during a voice callout.
- **Decision 3: Dual Word Discovery Tracking (Voice + Touch)**
  - *Chosen Approach*: If a player shouts a word, the game engine automatically finds the matching path on the grid and animates the line stroke from start to finish letter. If the player prefers to swipe or click start-to-end letters, it validates identically.
  - *Why*: Accessibility and adaptability across noisy cafes, quiet libraries, and boisterous living rooms.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────┐
│                           App.tsx                               │
│              (Game State Machine & Theme Provider)              │
└───────────────┬─────────────────────────────────┬───────────────┘
                │                                 │
     ┌──────────▼──────────┐           ┌──────────▼──────────┐
     │  Title / Setup Hub  │           │  Active Game Arena  │
     │  - Mode Selection   │           │  - HUD & Countdown  │
     │  - Audio Permission │           │  - Score & Streak   │
     │  - High Scores      │           │  - Sound Synthesis  │
     └─────────────────────┘           └──────────┬──────────┘
                                                  │
          ┌───────────────────────────────────────┴───────────────────────────────────────┐
          │                                       │                                       │
┌─────────▼──────────────┐             ┌──────────▼──────────────┐             ┌──────────▼──────────────┐
│   SpeechController     │             │     WordSearchGrid      │             │    AntonymBonusModal    │
│ - Continuous Mic Listen│             │ - 2D Matrix Generation  │             │ - 5s Countdown Window   │
│ - Live Audio Visualizer│             │ - Raycast Drag Selector │             │ - Antonym Validation    │
│ - Fuzzy/Phonetic Match │             │ - Word Path Highlighting│             │ - Score Bonus & Time +5 │
└────────────────────────┘             └─────────────────────────┘             └─────────────────────────┘
                                                  │
                                       ┌──────────▼──────────────┐
                                       │   OxfordLexiconEngine   │
                                       │ - Tiered Word Matrix    │
                                       │ - Antonym Graph / Bank  │
                                       │ - Definitions & Etymo   │
                                       └─────────────────────────┘
```

#### State Machine Flow:
- `TITLE_MENU` -> `PLAYING` -> (`ANTONYM_BONUS_WINDOW`) -> `ROUND_SUMMARY` -> `STAGE_PROGRESSION` / `GAME_OVER`
- Progressive parameters:
  - Level 1: 8x8 Grid, 4 Words (Tier 1: 4-5 letters), 90s timer.
  - Level 2: 9x9 Grid, 5 Words (Tier 2: 5-6 letters), 80s timer.
  - Level 3: 10x10 Grid, 6 Words (Tier 2-3: 6-7 letters), 70s timer.
  - Level 4: 11x11 Grid, 7 Words (Tier 3: 7-8 letters), 60s timer.
  - Level 5+: 12x12 Grid, 8 Words (Tier 4: 8-10 letters), 55s timer with fast antonym bonus multipliers.
